<script>
window.location = <?php   
  
$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";
if (file_get_contents("http://talk.uctc.xyz/talk/app/authToken.php?user=".$_GET["user"]."&token=".$_GET["token"]) == "true") {
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO mails (fromUser, toUser, subject, text)
VALUES ("."'".$_GET["user"] . "' , '".$_GET["toUser"] . "' , '".$_GET["subject"] . "' , '".$_GET["text"] . "')";

if ($conn->query($sql) === TRUE) {
    echo "'http://talk.uctc.xyz/talk/app/inbox.html';</script>";
} else {
    echo "'http://talk.uctc.xyz/talk/error.php?error=MYSQLERROR: " . $sql . "<br>" . $conn->error . "';</script>";
}
} else {
  echo "'http://talk.uctc.xyz/talk/error.php?error=AUTHERROR';</script>";
}
$conn->close();
      
  ?>
window.location = url;
</script>