<script>
var resp=<?php

$user = $_GET["user"];
$pass = $_GET["pass"];
$token = uniqid();
$fname = $_GET["fore"];
$sname = $_GET["sur"];
$gen = $_GET["mf"];
$yr = $_GET["yr"];
$form = $_GET["form"];
$dupe = $_GET["dupe_bool"];
$duser = $_GET["dupe_user"];
$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";
$cdid = $_GET["cdid"];
$user = str_replace(array("<",">"), ' ', $user);
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO `users` (user, password, token, fName, sName, gender, Year, Form, dupe, dupeuser , CDID)
VALUES ('".$user."','".$pass."','".$token."','".$fname."','".$sname."','".$gen."','".$yr."','".$form."',".$dupe.",'".$duser."','".$cdid."')";

if ($conn->query($sql) === TRUE) {
    echo '{"user":'.$user.'","pass":"'.$pass +'"}';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
    
//auto mail
$text = "Hi+" . $fname . ",\nWelcome+To+SamChat";
file_get_contents("http://talk.uctc.xyz/talk/app/sendMail.php?user=admin&token=5a27ff46b943d&toUser=". $user . "&subject=Welcome!&text=" . $text);

?>;
console.log(resp);
window.location.href = "http://talk.uctc.xyz/talk/" + "login.php" + "?" + ("user" + "=" + <?php echo '"'.$_GET["user"].'"';?>) + "&" + ("pass" + "=" + <?php echo '"'.$_GET["pass"].'"';?>)
</script>