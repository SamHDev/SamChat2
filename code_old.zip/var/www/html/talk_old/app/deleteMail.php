<?php

$id = $_GET["id"];

if (file_get_contents("http://api.samhdev.uk/talk/app/authToken.php?user=".$_GET["user"]."&token=".$_GET["token"]) == "true") {
  

$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("false");
} 

// sql to delete a record
$sql = "DELETE FROM `mails` WHERE id=".$id . "AND `toUser` NOT LIKE `*`";

if ($conn->query($sql) === TRUE) {
    echo "true";
} else {
    echo "false";
}

$conn->close();

} else {
  echo "false";
}

?>