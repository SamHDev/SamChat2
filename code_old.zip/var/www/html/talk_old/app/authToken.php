<?php

$user = $_GET["user"];
$token = $_GET["token"];


$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM `users` WHERE `user` LIKE '".$user."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if ($token == $row["token"]) {
          echo "true";
        } else {
          echo "false";
        }
    }
} else {
    echo "false";
}
$conn->close();
  
  
?>