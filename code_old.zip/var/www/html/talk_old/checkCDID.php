<?php 

$cdid = $_GET["cdid"];


$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("false");
} 

$sql = "SELECT user FROM `users` WHERE `CDID` LIKE '".$cdid."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "true";
    }
} else {
    echo "false";
}
$conn->close();

?>