<?php
$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";


if (file_get_contents("http://api.samhdev.uk/talk/app/authToken.php?user=".$_GET["user"]."&token=".$_GET["token"]) == "true") {
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sqls = "SELECT * FROM `mails` WHERE `id` = ".$_GET["id"]."";
$result = $conn->query($sqls);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $buffer = $row["text"];
        $buffer = str_replace(array("\n" , "\r"), '<br>', $buffer);
        $buffer = str_replace(array("<br><br>"), '<br>', $buffer);
        echo '{"id":"'.$row["id"].'","fromUser":"'.$row["fromUser"].'","toUser":"'.$row["toUser"].'","timedate":"'.$row["timedate"].'","subject":"'.$row["subject"].'","text":"'.$buffer.'"}';
    }
} else {
    echo "{}";
}
$conn->close();
} else {
  echo "{}";
}
?>