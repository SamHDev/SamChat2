<?php
$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sqls = "SELECT * FROM `live` WHERE `chatName` LIKE '".$_GET["chatName"]."' ORDER BY `MessageID` DESC LIMIT 30";
$result = $conn->query($sqls);
if (file_get_contents("http://api.samhdev.uk/talk/app/authToken.php?user=".$_GET["user"]."&token=".$_GET["token"]) == "true") {
if ($result->num_rows > 0) {
  echo '["NONE"';
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $buffer = $row["message"];
        $buffer = str_replace(array('"'), '<$11>', $buffer);
        echo ',{"messageID":"'.$row["messageID"].'","fromUser":"'.$row["fromUser"].'","chatName":"'.$row["chatName"].'","timedate":"'.$row["time"].'","text":"'.$buffer.'"}';
    }
    echo ']';
} else {
    echo '["NONE"]';
}
} else {
  echo '["NONE"]';
}
?>