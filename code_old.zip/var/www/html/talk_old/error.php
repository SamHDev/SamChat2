<html>
  <body>
    <h1>
      Oh Noes! An Error Happend!
    </h1>
    <h2>
      <?php echo $_GET["error"]; ?>
    </h2>
  </body>
</html>