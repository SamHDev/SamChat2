<?php

$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";

if (file_get_contents("http://api.samhdev.uk/talk/app/authToken.php?user=".$_GET["user"]."&token=".$_GET["token"]) == "true") {
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$text = $_GET["text"];
$text = str_replace(array("&#"), '<$12>', $text);
$text = str_replace(array("<"), '$15', $text);
$text = str_replace(array(">"), '$16', $text);
$sql = "INSERT INTO `live` (chatName, fromUser, message)
VALUES ("."'".$_GET["name"] . "' , '".$_GET["user"] . "' , '".$text . "')";

if ($conn->query($sql) === TRUE) {
    echo "'http://api.samhdev.uk/talk/app/inbox.html';</script>";
} else {
    echo "'http://api.samhdev.uk/talk/error.php?error=MYSQLERROR: " . $sql . "<br>" . $conn->error . "';</script>";
}
} else {
  echo "'http://api.samhdev.uk/talk/error.php?error=AUTHERROR';</script>";
}
$conn->close();

?>