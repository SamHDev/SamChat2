<?php

$id = $_GET["name"];


$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM `users` WHERE  `user` LIKE '" . $id . "'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo '{"user":"' . $row["user"] . '", "fName":"' . $row["fName"] . '", "sName":"' . $row["sName"] . '", "year":"' . $row["Year"] . '", "form":"' . $row["Form"] . '", "gender":"' . $row["gender"] . '"}';
    }
} else {
    echo "{}";
}
$conn->close();

  
  
?>