<?php
$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sqls = "SELECT * FROM `mails` WHERE `toUser` LIKE '".$_GET["user"]."' OR `toUser` LIKE '*'";
$result = $conn->query($sqls);
if (file_get_contents("http://talk.uctc.xyz/talk/app/authToken.php?user=".$_GET["user"]."&token=".$_GET["token"]) == "true") {
if ($result->num_rows > 0) {
  echo '["NONE"';
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo ',{"id":"'.$row["id"].'","fromUser":"'.$row["fromUser"].'","toUser":"'.$row["toUser"].'","timedate":"'.$row["timedate"].'","subject":"'.$row["subject"].'","text":"'.'NONE'.'"}';
    }
    echo ']';
} else {
    echo '["NONE"]';
}
} else {
  echo '["NONE"]';
}
$conn->close();
?>