<script>
var resp = <?php

$user = $_GET["user"];
$pass = $_GET["pass"];


$servername = "localhost";
$username = "samchat";
$password = "samchat123";
$dbname = "samchat2";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM `users` WHERE `user` LIKE '" . $user . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if ($row["password"] == $pass) {
        echo '{"type":"good", "response":"authed", "user":"'.$user.'", "token":"'. $row["token"] .'"}';
        } else {
          echo '{"type":"error","response":"Inncorect Password","user":"'.$user.'","token":"NONE"}';
          
        }
    }
} else {
    echo '{"type":"error","response":"User Not Found","user":"'.$user.'",token":"NONE"}';
}
$conn->close();


?>;
 console.log(resp);
 //var load = JSON.parse(resp);
  var load = resp;
  if (load["type"] == "error") {
    window.location.href = "http://talk.uctc.xyz/talk/" + "error.php?error=" + load["resp"];
  }  
  if (load["type"] == "good") {
    localStorage.setItem("SamChat_User",load["user"]);
    localStorage.setItem("SamChat_Token",load["token"]);
    window.location.href = "http://talk.uctc.xyz/talk/" + "app/inbox.html";
  }
 </script>